create table users(
                      user_id INTEGER IDENTITY primary key,
                      username varchar (255),
                      email varchar (255),
                      phonenumber varchar (255)
);